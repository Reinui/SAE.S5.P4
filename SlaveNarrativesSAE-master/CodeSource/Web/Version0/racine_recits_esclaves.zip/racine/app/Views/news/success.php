<p>News item created successfully.</p>
<br>
<a href="<?= base_url() ?>/news">Return to the news index</a>