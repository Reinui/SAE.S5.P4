<?php
namespace App\Models;

use CodeIgniter\Model;

class ModelFormulaire extends Model
{

    protected $table = 'tab_recits_v3';
	protected $allowedFields = ['id_recit', 'titre'];

    // TOUT LES attribue sont selectionné
    public function getRecit()
	{
	    
        return $this->asArray()
        ->findAll();

    }
}

class ModelGetPoints extends Model
{
    protected $table = 'points';
	protected $allowedFields = ['id'];

    public function getLastPoint()
    {

        $result =  $this->select('id')
                    ->orderBy('CAST(id AS UNSIGNED)', 'DESC')
                    ->limit(1)
                    ->get()
                    ->getRow();

        if ($result) {
            // Retournez l'ID en tant que chaîne
            return (string)$result->id+1;
        }
        return null;
    }
}
?>