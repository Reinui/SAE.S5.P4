<br><br><br><br>
<footer>
  <div class="text-center p-3">
    <a id="lienfoot" href="<?= site_url()."about" ?>">À propos</a>
    <a id="lienfoot" href="<?= site_url()."contact" ?>">Contact</a> 
  </div>
</footer> 

<style>

  footer{
    background-color:#a0512db9;
  }

</style>
</body>
</html>