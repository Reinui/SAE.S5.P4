<?php

namespace App\Controllers;

class Ajout extends BaseController
{
    public function point()
    {
        $model = model(ModelFormulaire::class);
        $model1 = model(ModelGetPoints::class);


        $data = [
            'title' => $model->getRecit(),
            'id_point' => $model1->getLastPoint()
        ];

        return view('resclaves/ajout_point', $data);
    }

    public function InsertPoint()
    {

        $coord = $this->request->getPost('coord');
        $ville = $this->request->getPost('ville');
        $type = $this->request->getPost('type');
        $id_recit = $this->request->getPost('recit');
        $id_point = $this->request->getPost('point');

        //if si >10

        $layer = 'points_R' . $id_recit . '_pt_' . $type;

        $licoord = is_string($coord) ? explode(',', $coord) : [];
        $licoord = count($licoord) === 2 ? $licoord : [];
        $wkt = 'POINT (' . $licoord[0] . ' ' . $licoord[1] . ')';
        $geoj = '{\"type\": \"Point\", \"coordinates\": [' . $licoord[1] . ', ' . $licoord[0] . ']}';

        // recupérer le dernier id de point

        $sql = 'INSERT INTO `points` (`WKT`, `ville`, `layer`,`id`, `id_recit`, `type`, `geoj`) VALUES (\'' . $wkt . '\',\'' . $ville . '\',\'' . $layer . '\',\'' . $id_point . '\',\'' . $id_recit . '\',\'' . $type . '\',\'' . $geoj . '\')';
        //echo $sql;
        $db = db_connect();
        $db->query($sql);

        return redirect()->to('/map');
    }
}
