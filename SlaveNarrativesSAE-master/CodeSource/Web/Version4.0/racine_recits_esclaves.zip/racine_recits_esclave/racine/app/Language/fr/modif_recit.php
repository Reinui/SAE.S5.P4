<?php

return [
    'title' => "Modifier un récit",
    'name_narrative' => 'Nom du récit',
    'name_slave' => "Nom de l'esclave",
    'location_publication' => 'Lieu de publication',
    'year_publication' => 'Année de publication',
    'type_narrative' => 'Type de récit',
    'comments' => 'Commentaires / Historiographie',
    'method_publication' => 'Mode de publication',
    'name_writer' => 'Nom du scribe / écrivain',
    'link_narrative' => 'Lien vers le récit',
    'modify_button' => 'Modifier'
];
