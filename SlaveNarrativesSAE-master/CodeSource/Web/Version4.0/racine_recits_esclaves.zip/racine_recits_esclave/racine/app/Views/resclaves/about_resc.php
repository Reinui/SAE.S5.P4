<br>

<div class="about">
<br>

<style>

    .about{
        background-color:rgb(225, 158, 6, 0.3);
        color:black;
        width:70%;
        position:relative;
        border-radius:15px;
        margin:auto;
    }

    .para{
        background-color:rgb(225, 158, 6, 0.3);
        text-align:center;
        width:80%;
        position:relative;
        border-radius:13px;
        margin:auto;
    }

</style>
<h3> <?= lang('about_resc.title') ?> </h3><br>


<div class= "para">

<br>
<p> <?= lang('about_resc.p1') ?></p><br>
<p><?= lang('about_resc.p2') ?><br>
<?= lang('about_resc.p3') ?><br>
<?= lang('about_resc.p4') ?><br>
<?= lang('about_resc.p5') ?><br>
</p>
<br><br>
</div>
<p class= "para"><?= lang('about_resc.thanks') ?>
    <br><br>
    <?= lang('about_resc.thanks_text') ?>
<br><br>
<?= lang('about_resc.p3') ?><br>
<?= lang('about_resc.p4') ?><br>
<?= lang('about_resc.p5') ?>
<br><br>
</p>
<br><br>
    </div>

</div>