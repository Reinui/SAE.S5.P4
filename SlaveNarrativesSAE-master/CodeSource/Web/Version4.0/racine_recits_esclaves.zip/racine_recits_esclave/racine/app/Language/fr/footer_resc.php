<?php

return [
    'about' => 'A propos',
    'contact' => 'Contact'
];