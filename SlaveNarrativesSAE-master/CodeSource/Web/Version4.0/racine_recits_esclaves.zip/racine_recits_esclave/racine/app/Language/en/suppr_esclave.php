<?php

return [
    'title' => 'Delete a slave',
    'select_slave' => 'Select a slave to delete',
   'delete_button' => 'Delete',
   'delete_confirmation' => 'Are you sure ?'
];
