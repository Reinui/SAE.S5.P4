<?php

return [
    'title' => 'Lier les territoires',
    'type_polys' => 'Choisir le types des territoires',
    'publi' => 'Publication',
    'naiss' => 'Naissance',
    'deces' => 'Décès',
    'esc' => 'Esclavage',
    'lieuv' => 'Lieu de vie',
    'add_button' => 'Lier',
];