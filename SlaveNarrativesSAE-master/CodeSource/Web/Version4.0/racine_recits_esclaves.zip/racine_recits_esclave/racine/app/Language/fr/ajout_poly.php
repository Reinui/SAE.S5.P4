<?php

return [
    'title' => 'Ajout polygone',
    'point' => "Liste des points ",
    'suppr' => 'Suppression du point',
    'poly_name' => 'Nom du polygone',
    'add_poly_button' =>'Ajouter le polygone'
];