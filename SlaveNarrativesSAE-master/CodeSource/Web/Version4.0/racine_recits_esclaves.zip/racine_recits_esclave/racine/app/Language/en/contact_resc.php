<?php

return [
    'title' => 'Contact us',
    'name' => 'Name',
    'email' => 'Email',
    'message' => 'Message',
    'send_button' => 'Send'
];
