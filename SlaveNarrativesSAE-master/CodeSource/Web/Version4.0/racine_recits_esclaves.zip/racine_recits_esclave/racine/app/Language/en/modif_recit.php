<?php

return [
    'title' => 'Modify a narrative',
    'name_narrative' => 'Narrative\'s title',
    'name_slave' => "Slave\s name",
    'location_publication' => 'Place of publication',
    'year_publication' => 'Year of publication',
    'type_narrative' => 'Type of narrative',
    'comments' => 'Comments / Historiography',
    'method_publication' => 'Method of publication',
    'name_writer' => 'Writer\'s name',
    'link_narrative' => 'Link to the narrative',
    'modify_button' => 'Modify'
];