<?php

return [
    'title' => 'Creating an account',
    'username' => "Username",
    'password' => 'Password',
    'back_button' => 'Back',
    'create_button' => 'Create account'
];
