<?php

return [
    'title' => "Ajout d'un point",
    'coordinates' => 'Coordonnées',
    'city' => 'Ville',
    'type' => 'Type',
    'types' => [
        'birth' => 'Naissance',
        'publication' => 'Publication',
        'death' => 'Décès',
        'slavery' => 'Esclavage',
        'location_life' => 'Lieu de vie'
    ],
    'attach_narrative' => "Joindre à un récit",
    'add_point_button' => 'Ajouter le point'
];