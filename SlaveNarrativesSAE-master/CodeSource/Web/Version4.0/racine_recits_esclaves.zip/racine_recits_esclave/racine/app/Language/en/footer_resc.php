<?php

return [
    'about' => 'About',
    'contact' => 'Contact'
];