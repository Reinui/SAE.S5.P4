<?php

return [
    'title' => "Création d'un compte",
    'username' => "Nom d'utilisateur",
    'password' => 'Mot de passe',
    'back_button' => 'Retour',
    'create_button' => 'Créer le compte'
];