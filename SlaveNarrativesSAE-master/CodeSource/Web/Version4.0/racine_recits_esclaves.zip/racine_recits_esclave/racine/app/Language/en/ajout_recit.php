<?php

return [
    'title' => 'Adding a narrative',
    'name_narrative' => 'Name of the narrative',
    'name_slave' => "Name of the slave",
    'location_publication' => 'Place of publication',
    'year_publication' => 'Year of publication',
    'type_narrative' => 'Type of narrative',
    'comments' => 'Comments / Historiography',
    'method_publication' => 'Method of publication',
    'name_writer' => 'Writer\'s name',
    'link_narrative' => 'Link to the narrative',
    'add_button' => 'Add',
    'choix_polys' => 'Choose the territories linked to the narrative'
];