<?php

return [
    'locations_publication_narratives' => 'Locations of publication of narratives',
    'popup' => [
        'date_publication' => 'Publication date',
        'visualize_narrative_map_button' => 'View the narrative map',
        'modify_button' => "Modify",
        'delete_button' => "Delete"
    ],
    'locations_birth' => 'Birthplace',
    'locations_publication' => 'Publication place',
    'locations_life' => 'Place of life',
    'locations_death' => 'Place of death',
    'locations_slavery' => 'Place of slavery'
];