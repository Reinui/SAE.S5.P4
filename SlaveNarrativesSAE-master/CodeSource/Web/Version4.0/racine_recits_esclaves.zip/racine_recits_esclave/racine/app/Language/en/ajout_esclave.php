<?php

return [
    'title' => 'Adding a slave',
    'name_slave' => "Slave name",
   'year_birth' => 'Birth year',
   'location_birth' => 'Birthplace',
   'year_death' => 'Year of death',
   'location_death' => 'Death place',
   'location_slavery' => "Living location during slavery",
   'means_release' => 'Means of emancipation',
   'location_life_after_release' => 'Living location after release',
   'origin_parents' => 'Parent\'s origin',
   'abolitionist_activist' => 'Abolitionist activist',
   'particularities' => 'Particularities',
   'add_button' => 'Add'
];
