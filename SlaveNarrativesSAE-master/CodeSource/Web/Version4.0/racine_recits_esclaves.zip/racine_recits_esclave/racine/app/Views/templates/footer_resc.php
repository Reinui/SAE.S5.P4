<br>
<footer>
  <div class="text-center p-3">
    <a id="lienfoot" href="<?= site_url()."about" ?>"><?= lang('footer_resc.about') ?></a>
    <a id="lienfoot" href="<?= site_url()."contact" ?>"><?= lang('footer_resc.contact') ?></a> 
  </div>
</footer> 

<style>

  footer{
    background-color:#a0512db9;
  }

</style>
</body>
</html>