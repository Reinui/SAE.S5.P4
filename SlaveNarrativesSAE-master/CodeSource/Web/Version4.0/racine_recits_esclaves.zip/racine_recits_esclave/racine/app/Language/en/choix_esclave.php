<?php

return [
    'title' => 'Choose a slave',
    'select_slave' => 'Select a slave to modify',
   'modify_button' => 'Modify'
];
