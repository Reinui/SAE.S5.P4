<?php

return [
    'title' => 'Add a polygon',
    'point' => 'List of points',
    'suppr' => "Delete Point",
    'poly_name' => 'Polygon Name',
    'add_poly_button' => 'Add Polygon'
];
