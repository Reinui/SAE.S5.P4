<?php

return [
    'title' => "Ajout d'un lien",
    'tab1' => "Ajouter un lien",
    'tab1_ch1' => "Nom du lien",
    'tab1_ch2' => "Lien",
    'tab1_add' => "Ajouter",
    'tab2' => "Tableau des liens",
    'tab2_name' => "Nom des liens",
    'tab2_link' => "Liens",
    'tab2_send' => "Stocker les liens",
];