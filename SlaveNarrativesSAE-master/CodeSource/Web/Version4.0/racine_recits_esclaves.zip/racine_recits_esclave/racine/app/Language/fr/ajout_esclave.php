<?php

return [
    'title' => "Ajout d'un esclave",
    'name_slave' => "Nom de l'esclave",
   'year_birth' => 'Année de naissance',
   'location_birth' => 'Lieu de naissance',
   'year_death' => 'Année de décès',
   'location_death' => 'Lieu de décès',
   'location_slavery' => "Lieu d'eslavage",
   'means_release' => 'Moyen de libération',
   'location_life_after_release' => 'Lieu de vie après libération',
   'origin_parents' => 'Origine des parents',
   'abolitionist_activist' => 'Militant abolitionniste',
   'particularities' => 'Particularités',
   'add_button' => 'Ajouter'
];
