<?php

return [
    'title' => 'Link territories',
    'type_polys' => 'Choose territories type',
    'publi' => 'Publication',
    'naiss' => 'Birthplace',
    'deces' => 'Death',
    'esc' => 'Slavery',
    'lieuv' => 'Living place',
    'add_button' => 'Link',
];