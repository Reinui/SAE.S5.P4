<?php

return [
    'nav_bar' => [
        'home' => 'Accueil',
        'list_narratives' => 'Liste des récits',
        'statistics' => "Statistiques"
    ],
    'title' => "Récits d'esclaves",
    'isConnected' => " (Administrateur)",
    'subtitle' => 'Chaque voix doit être entendue'
];
