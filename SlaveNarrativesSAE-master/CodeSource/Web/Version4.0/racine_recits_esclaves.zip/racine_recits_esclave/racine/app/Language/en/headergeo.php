<?php

return [
    'nav_bar' => [
        'home' => 'Home',
        'list_narratives' => 'List of narratives',
        'statistics' => "Statistics"
    ],
    'title' => 'Slave narratives',
    'isConnected' => ' (Administrator)',
    'subtitle' => 'Every voice needs to be heard'
];