<?php

return [
    'title' => 'Contactez-nous',
    'name' => 'Nom',
    'email' => 'Email',
    'message' => 'Message',
    'send_button' => 'Envoyer'
];
