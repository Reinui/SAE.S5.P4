<?php

return [
    'title' => "Choisir un esclave", 
    'select_slave' => 'Selectionner un esclave à modifier',
   'modify_button' => 'Modifier'
];
