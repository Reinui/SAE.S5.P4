<?php

return [
    'title' => "Adding a Link",
    'tab1' => "Add a Link",
    'tab1_ch1' => "Link Name",
    'tab1_ch2' => "Link URL",
    'tab1_add' => "Add",
    'tab2' => "Link Table",
    'tab2_name' => "Link Names",
    'tab2_link' => "Links",
    'tab2_send' => "Store Links",
];
