<?php

return [
    'title' => 'Connexion Admin',
    'username' => "Nom d'utilisateur",
    'password' => 'Mot de passe',
    'login_button' => 'Se connecter'
];
