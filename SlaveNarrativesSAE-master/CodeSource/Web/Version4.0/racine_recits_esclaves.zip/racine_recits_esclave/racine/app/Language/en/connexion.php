<?php

return [
    'title' => 'Admin Login',
    'username' => 'Username',
    'password' => 'Password',
    'login_button' => 'Log in'
];
