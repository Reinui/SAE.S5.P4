<?php

return [
    'title' => 'Supprimer un esclave',
    'select_slave' => 'Selectionner un esclave à supprimer',
   'delete_button' => 'Supprimer',
   'delete_confirmation' => 'Êtes-vous sûr ?'
];
